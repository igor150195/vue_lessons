<template>
	<div class="container mt-3">
		<form v-if="!formDone" @submit.prevent="sendForm">
			<b-progress :max="info.length" :value="fieldsDone"></b-progress>
			<div>
				<app-field 
					v-for="(field, i) in info"
					:key="i"
					:value="field.value"	
					:name="field.name"	
					:valid="field.valid"
					@updated="onInput(i, $event)"
				></app-field>
			</div>
			<button class="btn btn-primary" :disabled="!formReady">
				Send Data
			</button>
		</form>
		<div v-else>
			<h2>All done</h2>
		</div>
		<b-modal v-model="showConfirm" @ok="onConfirm">
			<table class="table table-bordered">
				<tbody>
					<tr v-for="(field, i) in info" :key="i">
						<td>{{ field.name }}</td>
						<td>{{ field.value }}</td>
					</tr>
				</tbody>
			</table>
		</b-modal>
	</div>
</template>
<script>
import AppField from '@/components/Field.vue'
import { BProgress, BModal} from 'bootstrap-vue'
 
export default {
	components: {
		AppField,
		BProgress,
		BModal
	},
	data: () => ({
		info: [
			{
				name: 'Name',
				value: '',
				pattern: /^[a-zA-Z ]{2,30}$/
			},
			{
				name: 'Phone',
				value: '',
				pattern: /^[0-9]{7,14}$/
			},
			{
				name: 'Email',
				value: '',
				pattern: /.+/
			},
			{
				name: 'Some Field 1',
				value: '',
				pattern: /.+/
			},
			{
				name: 'Some Field 2',
				value: '',
				pattern: /.+/
			}
		],
		formDone: false,
		showConfirm: false
	}),
	computed: {
		fieldsDone(){
			return this.info.reduce((total, field) => {
				return total + (field.valid ? 1 : 0);
			}, 0);
		},
		formReady(){
			return this.fieldsDone === this.info.length;
		}
	},
	methods: {
		onInput(i, value){
			let field = this.info[i];
			field.value = value.trim();
			field.valid = field.pattern.test(field.value);
		},
		sendForm(){
			if(this.formReady){
				this.showConfirm = true;
			}
		},
		onConfirm(){
			this.formDone = true;
		}
	},
	created(){
		return this.info.forEach(field => {
			this.$set(field, 'valid', field.pattern.test(field.value)); 
		});
	}
}
</script>