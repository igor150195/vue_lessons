module.exports = {
	//publicPath: ''
}