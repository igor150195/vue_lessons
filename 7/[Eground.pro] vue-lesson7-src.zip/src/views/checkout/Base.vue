<template>
	<div>
		<h1>Order now</h1>
		<hr>
		<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptas enim architecto odio perspiciatis quos at quisquam, iste aliquid unde, repellendus sequi quis beatae tempora vero dolores minus voluptatibus eius nam?</p>
		<router-view></router-view>
	</div>
</template>

<script>
	export default {
		
	}
</script>