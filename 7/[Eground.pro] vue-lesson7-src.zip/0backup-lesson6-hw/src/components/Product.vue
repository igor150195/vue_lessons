<template>
	<div>
		<h2>Product title</h2>
		<div class="price">{{ price }}</div>
		<hr>
		<button class="btn btn-warning" @click="decrease">-1</button>
		<input type="text" :value="cnt" @change="onInput">
		<button class="btn btn-success" @click="increase">+1</button>
	</div>
</template>
<script>
	import { mapGetters, mapActions } from 'vuex';

	export default {
		computed: mapGetters(['price', 'cnt']),
		methods: {
			...mapActions(['decrease', 'increase', 'setCnt']),
			onInput(e){
				let lastCnt = this.cnt;
				this.setCnt(e.target.value);
				
				if(lastCnt === this.cnt && lastCnt.toString() !== e.target.value){
					//this.$forceUpdate();
					e.target.value = lastCnt;
				}
			}
		}
	}
</script>