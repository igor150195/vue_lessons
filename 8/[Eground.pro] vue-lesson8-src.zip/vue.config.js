module.exports = {
	filenameHashing: false,
	productionSourceMap: false
}