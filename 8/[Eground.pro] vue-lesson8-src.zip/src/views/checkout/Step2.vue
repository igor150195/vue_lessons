<template>
	<h2>Step 2</h2>
</template>

<script>
	export default {
		
	}
</script>