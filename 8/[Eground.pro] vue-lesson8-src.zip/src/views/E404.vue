<template>
	<app-e404></app-e404>
</template>

<script>
	import AppE404 from '@/components/E404';

	export default {
		components: {
			AppE404
		}
	}
</script>