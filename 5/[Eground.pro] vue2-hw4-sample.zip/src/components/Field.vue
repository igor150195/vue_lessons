<template>
	<div class="form-group">
		<label>{{ name }}</label>
		<fa-icon v-if="activated" :name="icon" :class="iconClasses"></fa-icon>
		<input type="text" 
			class="form-control" 
			:value="value"
			@input="onInput"
		>
	</div>
</template>
<script>
import FaIcon from 'vue-awesome/components/Icon'
import 'vue-awesome/icons/check-circle'
import 'vue-awesome/icons/exclamation-circle'

export default {
	components: {
		FaIcon
	},
	props: ['name', 'value', 'valid'],
	data(){
		return {
			activated: this.value !== ''
		}
	},
	computed: {
		icon(){
			return this.valid ? 'check-circle' : 'exclamation-circle';
		},
		iconClasses(){
			return this.valid ? 'text-success' : 'text-danger';
		}
	},
	methods: {
		onInput(e){
			this.activated = true;
			this.$emit('updated', e.target.value);
		}
	}
}
</script>