module.exports = {
	publicPath: ''
}